#include<bits/stdc++.h>
using namespace std;
const int nmax=1000011;

int n,m,lab[nmax],k,b[nmax],ans[nmax];
vector<int> e[nmax],U,V;

void dfs(int x){
    if (lab[x]) return;
    lab[x]=k;
    for(int i=e[x].size();i--;) dfs(e[x][i]);
}

bool check(int x,int t){
    if (b[x]!=0) return b[x]==t;
    b[x]=t;
    for (int i=e[x].size();i--;) if (!check(e[x][i],-t)) return 0;
    return 1;
}

int main(){
    scanf("%d%d",&n,&m);
    for (int i=0;i<m;++i){
        int u,v,val;
        scanf("%d%d%d", &u,&v,&val);
        if (val){
            U.push_back(u);
            V.push_back(v);
            continue;
        }
        e[u].push_back(v);
        e[v].push_back(u);
    }
    k=0;
    for (int i=1;i<=n;++i) if (!lab[i]){
        ++k;
        dfs(i);
    }
    for (int i=1;i<=k;++i) e[i].clear();
    for (int i=U.size();i--;){
        e[lab[U[i]]].push_back(lab[V[i]]);
        e[lab[V[i]]].push_back(lab[U[i]]);
    }
    int ok=1;
    for (int i=1;i<=k;++i) if (!b[i]){
        if (!check(i,1)) ok=0;
    }
    if (ok){
        for (int i = 1; i <= n; ++i)
            ans[i] = b[lab[i]] == 1;
        for (int i = 1; i <= n; ++i) printf("%d ", ans[i]);
    } else printf("-1\n");    
}
