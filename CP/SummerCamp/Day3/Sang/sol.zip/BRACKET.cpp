#include <bits/stdc++.h>
using namespace std;

const int delta = 10002;
const int mod = 1000000007;
const int maxn = 10002;

pair<int,int>  b[maxn];
int n, dp[maxn][maxn*2], pos[maxn], m = 0;

inline void Add(int &x, int y){
    x += y;
    if (x >= mod) x -= mod;
}

int32_t main(int32_t argc,char** argv){
	ios_base::sync_with_stdio(0); cin.tie(); cout.tie();
    if (argc>1 && freopen(argv[1],"r",stdin));
    if (argc>2 && freopen(argv[2],"w",stdout));
    cin >> n;
    int cur = 0, xmin = 0;
    for (int i = 1; i <= n; ++i){
        char c;
        cin >> c;
        if (c == '?'){
            b[++m] = {cur, xmin};
            pos[m] = i;
            cur = xmin = 0;
        } else if (c == '(') cur ++;
            else xmin = min(xmin, --cur);
    }
    dp[0][delta] = 1;
    int ncur = 0;
    for (int i = 0; i <= m-1; i++){
        for (int j = delta - i; j <= delta + i; j+=2)
            if (ncur + j + b[i+1].second >= delta) {
                Add(dp[i+1][j+1], dp[i][j]);
                Add(dp[i+1][j-1], dp[i][j]);
            }
        ncur += b[i+1].first;
    }
    long long res = dp[m][delta-ncur-cur];
    if (cur != xmin ) res = 0;
    cout << res % mod;
    // cerr << res % mod << endl;
    return 0;
}
